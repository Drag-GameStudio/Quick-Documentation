import os 

os.system("pip install -U g4f")